const Movimento = {
    cima: 0,
    baixo: 1,
    esq: 2,
    drt: 3,
};

export default Movimento